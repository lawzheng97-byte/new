/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import ToolCard from './components/ToolCard';
import Pagination from './components/Pagination';
import Footer from './components/Footer';
import { TOOLS } from './types';
import { Filter, SortAsc } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 pt-24 pb-20 px-6 max-w-screen-2xl mx-auto flex flex-col lg:flex-row gap-8 w-full">
        <Sidebar />
        
        <section className="flex-1">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-on-surface mb-2">探索 AI 的无限可能</h1>
              <p className="text-slate-400 max-w-lg">
                为您精选全球范围内最具创新力的 AI 工具，从大语言模型到艺术创作，助力您的数字化转型。
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#141c2e] border border-outline-variant text-sm hover:border-primary transition-all text-slate-300">
                <Filter className="w-4 h-4" /> 筛选
              </button>
              <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#141c2e] border border-outline-variant text-sm hover:border-primary transition-all text-slate-300">
                <SortAsc className="w-4 h-4" /> 最热
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {TOOLS.map((tool) => (
              <ToolCard key={tool.id} tool={tool} />
            ))}
          </div>

          <Pagination />
        </section>
      </main>

      <Footer />
    </div>
  );
}
